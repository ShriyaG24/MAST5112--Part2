import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, Image, Picker, Button } from 'react-native';

const EnterScreen: React.FC = () => {
  const [dishName, setDishName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [selectedCourse, setSelectedCourse] = useState('Appetizer');
  const [showItemDetails, setShowItemDetails] = useState(false);

  const handleSave = () => {
    setShowItemDetails(true);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
      <Image 
          source={require('./assets/Logo.png')} 
          style={styles.logo}
        />
        <Text style={styles.headerText}>Enter Screen</Text>
      </View>
       <Text style={styles.menuTitle}>Menu Item:</Text>

      <TextInput 
        style={styles.input} 
        placeholder="Dish Name" 
        value={dishName} 
        onChangeText={setDishName} 
      />
      <TextInput 
        style={styles.input} 
        placeholder="Description" 
        value={description} 
        onChangeText={setDescription} 
      />
      <TextInput 
        style={styles.input} 
        placeholder="Price of Dish" 
        keyboardType="numeric" 
        value={price} 
        onChangeText={setPrice} 
      />
      <Picker
        selectedValue={selectedCourse}
        style={styles.picker}
        onValueChange={(itemValue) => setSelectedCourse(itemValue)}
      >
        <Picker.Item label="Appetizer" value="Appetizer" />
        <Picker.Item label="Hors d'oeuvre" value="Hors d'oeuvre" />
        <Picker.Item label="Main Course" value="Main Course" />
        <Picker.Item label="Dessert" value="Dessert" />
      </Picker>

     
      <Button title="Save" onPress={handleSave} />

      
      {showItemDetails && (
        <View style={styles.itemBox}>
          <Text style={styles.itemHeader}>{dishName}</Text>
          <Text style={styles.itemDescription}>{description}</Text>
          <Text style={styles.itemPrice}>R{price}</Text>
          <Text style={styles.itemSubheader}>{selectedCourse}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#eebec6',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  logo: {
    width: 40,
    height: 40,
    position: 'absolute',
    left: 16,
  },
 
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  menuTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  input: {
    height: 40,
    borderColor: 'black',
    borderWidth: 2,
    marginBottom: 12,
    paddingLeft: 8,
  },
  picker: {
    height: 50,
    width: '100%',
    marginBottom: 20,
    borderWidth: 2,
    borderColor:'black',
  },
  itemBox: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 8,
    marginTop: 20,
  },
  itemHeader: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  itemDescription: {
    marginVertical: 5,
  },
  itemPrice: {
    fontWeight: 'bold',
  },
  itemSubheader: {
    fontStyle: 'italic',
  },
});

export default EnterScreen;
