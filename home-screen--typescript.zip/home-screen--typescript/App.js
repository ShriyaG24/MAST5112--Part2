import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView, Button} from 'react-native';

const HomeScreen: React.FC = () => {
  const totalCourses = 5; 
  const averagePrice = 220; 
 const handleNext = () => { 
    console.log("Next button pressed!");
 };
  return (
    <View style={styles.container}>
    <Image 
        source={require('./assets/Logo.png')} 
        style={styles.logo}
      />
      <View style={styles.header}>
        <Text style={styles.headerText}>Home</Text>
      </View>
      <View style={styles.infoContainer}>
        <View style={styles.box}>
          <Text style={styles.boxText}>Total Courses: {totalCourses}</Text>
        </View>
        <View style={styles.box}>
          <Text style={styles.boxText}>Avg Meal Price: {averagePrice}</Text>
        </View>
      </View>
      <ScrollView style={styles.menuContainer}>
        <Text style={styles.menuTitle}>Menu Items:</Text>
        <Text style={styles.menuItem}>
          <Text style={styles.itemTitle}>Appetizers:</Text>
          {'\n'}Halloumi Sticks: Four lightly dusted Halloumi sticks fried or grilled, served with lemon wedge on the side and a sweet chilli dipping sauce.
        </Text>
        <Text style={styles.menuItem}>
          <Text style={styles.itemTitle}>Hors d'oeuvre:</Text>
          {'\n'}Mussels: Half-shelled mussels baked in a garlic sauce OR in a creamy white sauce.
        </Text>
        <Text style={styles.menuItem}>
          <Text style={styles.itemTitle}>Mains:</Text>
          {'\n'}Chicken Mayo Pizza: Chopped cooked chicken, chopped tomato, and green chilies, grated parmesan cheese, fresh garlic and black pepper topped with mozzarella cheese.
        </Text>
        <Text style={styles.menuItem}>
          <Text style={styles.itemTitle}>Baked Salmon:</Text>
          {'\n'}With black pepper, minced garlic, herb seasoning and a slice of lemon.
        </Text>
        <Text style={styles.menuItem}>
          <Text style={styles.itemTitle}>Dessert:</Text>
          {'\n'}Brownies: Side of vanilla ice cream.
          <Button 
        title="Next" 
        color="#841584" // Change this to your desired color
        onPress={handleNext} // Use the correct handler
      />
        </Text>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#eebec6',
  },
   logo: {
    width: 120, 
    height: 130,
    marginBottom: 20,
  },
   header: {
    height: 50, // Adjust height as needed
    justifyContent: 'flex-end', // Align items to the bottom
    alignItems: 'center', // Center horizontally
    paddingBottom: 20, // Add some padding to push text lower
  },

  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  infoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  box: {
    backgroundColor: '#f0f0f0',
    padding: 16,
    borderRadius: 8,
    width: '48%',
    borderBottomWidth: 5
  },
  boxText: {
    fontSize: 16,
  },
  menuContainer: {
    flex: 1,
  },
  menuTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  menuItem: {
    marginBottom: 15,
  },
  itemTitle: {
    fontWeight: 'bold',
  },
});

export default HomeScreen;
