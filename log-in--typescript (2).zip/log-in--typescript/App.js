import React from 'react';
import { View, Text, Button, StyleSheet, Image } from 'react-native';

const WelcomeScreen = () => {
  const handleLogin = () => {
    console.log("Logging in...");
   
  };

  const handleChristoffel = () => { 
    console.log("Christoffel button pressed!");
    
  };

  return (
   <View style={styles.container}>
      <View style={styles.header}>
        <Image 
          source={require('./assets/Logo.png')} 
          style={styles.logo}
        />
      <Text style={styles.welcomeText}>Welcome</Text>
      <Button 
        title="Christoffel" 
        color="#8c52ff" 
        onPress={handleChristoffel} 
      />
      <View style={styles.spacer} />
      <Button 
        title="Log In" 
        color="#007BFF" // 
        onPress={handleLogin} 
      />
    </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#cecece',
  },
  logo: {
    width: 120, 
    height: 130,
    marginBottom: 20,
  },
  welcomeText: {
    fontSize: 24,
    marginBottom: 20,
  },
  spacer: {
    height: 20, // Adjust the height as needed
  },
});

export default WelcomeScreen;
